# Status Downloader

This app is used to download whatsapp status photo and videos. you can upload this app in playstore as well. there are lot's of application available like WhatsApp Story Saver, Story Downloader for whatsapp. 

![Webp net-gifmaker (2)](https://user-images.githubusercontent.com/13075784/60452848-29403780-9c4d-11e9-9a73-4128b53a759f.gif)

Show your supprt by giving star to this Repo as well as Follow me on Twitter & Instagram : @digitalchauhan
 
Do you want to learn how it works? 
Read my article for this : https://flutterian.com/whatsapp-status-downloader-using-flutter-with-admob/
